## Description: <br>
见外知识库自动安装 WeKnora CLI 和 OfficeCLI，配置访问凭据、导入、浏览和检索资料，并把指定知识库或文件夹中的证据交给 OfficeCLI，完成 Word/Excel 新建、重写、修正与计算。 <br>

此 skill 可用于商业或非商业场景。 <br>

## Publisher: <br>
[lyingbug](https://clawhub.ai/user/lyingbug) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
用户安装 skill 后，AI 在首次调用时自动从可校验的 CNB Release 安装 WeKnora CLI，从 OfficeCLI 官方源安装 OfficeCLI 1.0.144+（不接受未验证的 2.x），再配置 macOS、Linux 或 Windows 用户级凭据。之后可通过 AI 管理知识库、限定文件夹取材，并新建或修改经过验证的 DOCX/XLSX。 <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
风险：自动安装会向用户目录写入可执行文件；见外知识库 API Key 可能允许 AI 创建、编辑或删除知识库内容；用户级环境变量不是加密存储；Office 修改可能影响公式或版式。 <br>
缓解措施：WeKnora CLI 锁定腾讯官方上游提交、CNB 流水线和双层 SHA-256，OfficeCLI 锁定官方安装器哈希并限定已验证版本范围；已有不同版本不自动覆盖；使用最小权限 Key；限定知识范围；证据原件只读前后校验哈希；OfficeCLI 默认原子 batch，只生成新文件并执行结构、issues、版式、公式缓存和数值验收；默认不回传知识库。 <br>


## Reference(s): <br>
- [ClawHub skill page](https://clawhub.ai/lyingbug/skills/weknora) <br>


## Skill Output: <br>
**Output Type(s):** [文本、Markdown、代码、配置、DOCX、XLSX、变更清单、验证报告] <br>
**Output Format:** [包含 bash、PowerShell 和 JSON 示例的 Markdown 指引] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [API 调用前检查凭据；Office 任务保留知识来源、修改范围和验收状态，不静默覆盖或自动回传。] <br>

## Skill Version(s): <br>
1.6.2（修复 Windows 验活阶段的 PowerShell JSON 解析问题，改用 CLI 退出码与 true 标量门；保留 v1.6.1 的 BOM 和 stdin 修复） <br>

## Ethical Considerations: <br>
用户应确认此 skill 适用于当前环境，并遵守组织的安全、密钥管理和合规要求。 <br>
