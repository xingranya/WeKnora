#!/usr/bin/env bash

set -euo pipefail

script_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
install_dir="${WEKNORA_CLI_INSTALL_DIR:-$HOME/.local/bin}"

fail() {
  printf 'CLI 自举失败：%s\n' "$1" >&2
  exit 1
}

"$script_dir/install_weknora_cli.sh"
"$script_dir/ensure_officecli.sh"

[[ -n "${WEKNORA_BASE_URL:-}" ]] || fail "缺少 WEKNORA_BASE_URL，请先执行凭据自动配置。"
[[ -n "${WEKNORA_API_KEY:-}" ]] || fail "缺少 WEKNORA_API_KEY，请先执行凭据自动配置。"

base_url="${WEKNORA_BASE_URL%/}"
[[ "$base_url" == */api/v1 ]] || fail "WEKNORA_BASE_URL 必须以 /api/v1 结尾。"
cli_host="${base_url%/api/v1}"

printf '%s\n' "$WEKNORA_API_KEY" \
  | bash "$script_dir/configure_macos_env.sh" "$base_url" "$install_dir"

binary="$install_dir/weknora"
[[ -x "$binary" ]] || fail "WeKnora CLI 不可执行：$binary"

auth_projection="$(
  WEKNORA_HOST="$cli_host" WEKNORA_API_KEY="$WEKNORA_API_KEY" \
    "$binary" auth status --format json --jq '.data | {host,auth_source,is_active}'
)" || fail "auth status 验活失败。"
grep -Eq '"is_active"[[:space:]]*:[[:space:]]*true' <<< "$auth_projection" \
  || fail "auth status 未证明当前账号处于启用状态。"

kb_projection="$(
  WEKNORA_HOST="$cli_host" WEKNORA_API_KEY="$WEKNORA_API_KEY" \
    "$binary" kb list --format json \
      --jq '{ok:.ok,total_count:(.meta.total_count // .meta.count // (.data | length))}'
)" || fail "kb list 无法读取用户自己的知识库。"
grep -Eq '"ok"[[:space:]]*:[[:space:]]*true' <<< "$kb_projection" \
  || fail "kb list 未返回 ok=true。"

printf '%s\n' "$auth_projection"
printf '%s\n' "$kb_projection"
printf 'configured=true\n'
printf 'authenticated=true\n'
printf 'knowledge_base_access=true\n'
