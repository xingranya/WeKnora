﻿[CmdletBinding()]
param(
    [string]$InstallDir = (Join-Path $env:LOCALAPPDATA "Programs\WeKnora")
)

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

$scriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
& (Join-Path $scriptDir "install_weknora_cli_windows.ps1") -InstallDir $InstallDir
& (Join-Path $scriptDir "ensure_officecli_windows.ps1")

function Resolve-ConfigurationPowerShell {
    $pwshCommand = Get-Command "pwsh.exe" -ErrorAction SilentlyContinue
    if (-not $pwshCommand) {
        $pwshCommand = Get-Command "pwsh" -ErrorAction SilentlyContinue
    }
    if ($pwshCommand -and $pwshCommand.Source) {
        return $pwshCommand.Source
    }

    $windowsPowerShell = Join-Path $PSHOME "powershell.exe"
    if (Test-Path $windowsPowerShell -PathType Leaf) {
        return [IO.Path]::GetFullPath($windowsPowerShell)
    }
    $fallbackCommand = Get-Command "powershell.exe" -ErrorAction SilentlyContinue
    if ($fallbackCommand -and $fallbackCommand.Source) {
        return $fallbackCommand.Source
    }
    throw "CLI 自举失败：找不到 pwsh 或 powershell.exe。"
}

if ([string]::IsNullOrWhiteSpace($env:WEKNORA_BASE_URL)) {
    $env:WEKNORA_BASE_URL = [Environment]::GetEnvironmentVariable("WEKNORA_BASE_URL", "User")
}
if ([string]::IsNullOrWhiteSpace($env:WEKNORA_API_KEY)) {
    $env:WEKNORA_API_KEY = [Environment]::GetEnvironmentVariable("WEKNORA_API_KEY", "User")
}
if ([string]::IsNullOrWhiteSpace($env:WEKNORA_BASE_URL) -or [string]::IsNullOrWhiteSpace($env:WEKNORA_API_KEY)) {
    throw "CLI 自举失败：缺少见外知识库凭据。"
}

$normalizedBaseUrl = $env:WEKNORA_BASE_URL.Trim().TrimEnd([char[]]"/")
if (-not $normalizedBaseUrl.EndsWith("/api/v1", [StringComparison]::OrdinalIgnoreCase)) {
    throw "CLI 自举失败：WEKNORA_BASE_URL 必须以 /api/v1 结尾。"
}
$env:WEKNORA_HOST = $normalizedBaseUrl.Substring(0, $normalizedBaseUrl.Length - "/api/v1".Length)

$configurationScript = Join-Path $scriptDir "configure_windows_env.ps1"
$configurationPowerShell = Resolve-ConfigurationPowerShell
$env:WEKNORA_API_KEY |
    & $configurationPowerShell -NoLogo -NoProfile -NonInteractive -ExecutionPolicy Bypass -File $configurationScript `
        -BaseUrl $normalizedBaseUrl -CliInstallDir $InstallDir
if ($LASTEXITCODE -ne 0) {
    throw "CLI 自举失败：见外知识库凭据配置脚本执行失败。"
}
$binary = Join-Path ([IO.Path]::GetFullPath($InstallDir)) "weknora.exe"

$authActiveOutput = & $binary auth status --format json --jq '.data.is_active'
$authStatusExitCode = $LASTEXITCODE
if ($authStatusExitCode -ne 0) { throw "CLI 自举失败：auth status 验活失败。" }
$authActive = ($authActiveOutput -join "").Trim()
if (-not [string]::Equals($authActive, "true", [StringComparison]::OrdinalIgnoreCase)) {
    throw "CLI 自举失败：当前账号未证明处于启用状态。"
}

$kbListOKOutput = & $binary kb list --format json --jq '.ok'
$kbListExitCode = $LASTEXITCODE
if ($kbListExitCode -ne 0) { throw "CLI 自举失败：kb list 无法读取用户知识库。" }
$kbListOK = ($kbListOKOutput -join "").Trim()
if (-not [string]::Equals($kbListOK, "true", [StringComparison]::OrdinalIgnoreCase)) {
    throw "CLI 自举失败：kb list 未返回 ok=true。"
}

Write-Output "auth_is_active=true"
Write-Output "kb_list_ok=true"
Write-Output "configured=true"
Write-Output "authenticated=true"
Write-Output "knowledge_base_access=true"
