#!/usr/bin/env bash

set -euo pipefail

readonly INSTALLER_URL="https://d.officecli.ai/install.sh"
readonly INSTALLER_SHA256="2a0fdae06f4a018ea8d8516c69bfa5eeeb53406aacb5fa16fd07a9e572991bb6"
readonly MINIMUM_VERSION="1.0.144"
readonly MAXIMUM_VERSION_EXCLUSIVE="2.0.0"
readonly MINIMUM_MAJOR=1
readonly MINIMUM_MINOR=0
readonly MINIMUM_PATCH=144

temporary_dir=""

cleanup() {
  [[ -z "$temporary_dir" ]] || rm -rf "$temporary_dir"
}

fail() {
  printf 'OfficeCLI 安装失败：%s\n' "$1" >&2
  exit 1
}

sha256_file() {
  if command -v sha256sum >/dev/null 2>&1; then
    sha256sum "$1" | awk '{print $1}'
  elif command -v shasum >/dev/null 2>&1; then
    shasum -a 256 "$1" | awk '{print $1}'
  else
    fail "缺少 sha256sum 或 shasum。"
  fi
}

resolve_officecli() {
  if command -v officecli >/dev/null 2>&1; then
    command -v officecli
  elif [[ -x "$HOME/.local/bin/officecli" ]]; then
    printf '%s\n' "$HOME/.local/bin/officecli"
  fi
}

officecli_version() {
  "$1" --version 2>/dev/null | head -n 1
}

version_is_compatible() {
  local version="$1"
  [[ "$version" =~ ^([0-9]+)\.([0-9]+)\.([0-9]+)$ ]] || return 1
  local major="${BASH_REMATCH[1]}" minor="${BASH_REMATCH[2]}" patch="${BASH_REMATCH[3]}"
  (( major == MINIMUM_MAJOR \
    && (minor > MINIMUM_MINOR || (minor == MINIMUM_MINOR && patch >= MINIMUM_PATCH)) ))
}

trap cleanup EXIT

officecli_path="$(resolve_officecli || true)"
if [[ -n "$officecli_path" ]] && "$officecli_path" --version >/dev/null 2>&1; then
  current_version="$(officecli_version "$officecli_path")"
  if version_is_compatible "$current_version"; then
    printf 'officecli_path=%s\n' "$officecli_path"
    printf 'officecli_installed=reused\n'
    printf 'officecli_version=%s\n' "$current_version"
    exit 0
  fi
  [[ "${OFFICECLI_REPLACE:-0}" == 1 ]] \
    || fail "已有 OfficeCLI 不在支持范围 ${MINIMUM_VERSION} 至 ${MAXIMUM_VERSION_EXCLUSIVE}（不含）内，或版本无法解析；确认升级或替换后设置 OFFICECLI_REPLACE=1。"
fi

command -v curl >/dev/null 2>&1 || fail "缺少 curl。"
temporary_dir="$(mktemp -d "${TMPDIR:-/tmp}/officecli-install.XXXXXX")"
installer_path="$temporary_dir/install.sh"

curl --silent --show-error --fail --location --proto '=https' --tlsv1.2 \
  --connect-timeout 15 --max-time 60 "$INSTALLER_URL" --output "$installer_path"
[[ "$(sha256_file "$installer_path")" == "$INSTALLER_SHA256" ]] \
  || fail "官方安装脚本与 Skill 锁定的 SHA-256 不一致，请先更新 Skill。"
bash -n "$installer_path" || fail "官方安装脚本语法验证失败。"
bash "$installer_path"

officecli_path="$(resolve_officecli || true)"
[[ -n "$officecli_path" ]] || fail "安装后仍找不到 officecli。"
"$officecli_path" --version >/dev/null 2>&1 || fail "安装后版本验证失败。"

if [[ "$(uname -s)" == Darwin ]]; then
  codesign -v --strict "$officecli_path" 2>/dev/null \
    || fail "OfficeCLI 的 macOS 开发者签名验证失败。"
fi

printf 'officecli_path=%s\n' "$officecli_path"
printf 'officecli_installed=official_installer\n'
installed_version="$(officecli_version "$officecli_path")"
version_is_compatible "$installed_version" \
  || fail "OfficeCLI 安装版本不在支持范围 ${MINIMUM_VERSION} 至 ${MAXIMUM_VERSION_EXCLUSIVE}（不含）内。"
printf 'officecli_version=%s\n' "$installed_version"
