﻿[CmdletBinding()]
param(
    [string]$InstallDir = (Join-Path $env:LOCALAPPDATA "Programs\WeKnora")
)

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

$pinnedCommit = "7f11b7b5b9bb"
$pinnedReleaseTag = "cli-main-7f11b7b5b9bb-1"
$pinnedChecksumsSha256 = "4f818b55f18b575c9e3833955058b768bcfa25ea2c50ea6df81631523e285226"
$defaultReleaseBase = "https://cnb.cool/xingranya/weknora-cli/-/releases/download/$pinnedReleaseTag"
$releaseBase = if ([string]::IsNullOrWhiteSpace($env:WEKNORA_CLI_RELEASE_BASE_URL)) { $defaultReleaseBase } else { $env:WEKNORA_CLI_RELEASE_BASE_URL.TrimEnd('/') }

if (-not $releaseBase.StartsWith("https://", [StringComparison]::OrdinalIgnoreCase)) {
    throw "WeKnora CLI 安装失败：下载地址必须使用 HTTPS。"
}
if (-not [Environment]::Is64BitOperatingSystem) {
    throw "WeKnora CLI 安装失败：仅提供 Windows amd64 制品。"
}

$normalizedInstallDir = [IO.Path]::GetFullPath($InstallDir)
$target = Join-Path $normalizedInstallDir "weknora.exe"
if (Test-Path $target) {
    if (Test-Path $target -PathType Container) {
        throw "WeKnora CLI 安装失败：目标路径是目录，拒绝替换。"
    }
    $currentMetadata = (& $target version --format json 2>$null) -join ""
    if ($LASTEXITCODE -eq 0 -and $currentMetadata.Contains("`"commit`":`"$pinnedCommit`"")) {
        Write-Output "cli_path=$target"
        Write-Output "installed=reused"
        exit 0
    }
    if ($env:WEKNORA_CLI_REPLACE -ne "1") {
        throw "WeKnora CLI 安装失败：已存在不同版本，未经明确授权不自动覆盖。"
    }
}

$temporaryDir = Join-Path ([IO.Path]::GetTempPath()) ("weknora-cli-install-" + [Guid]::NewGuid().ToString("N"))
New-Item -ItemType Directory -Path $temporaryDir | Out-Null
try {
    $asset = "weknora-windows-amd64.exe"
    $checksumsPath = Join-Path $temporaryDir "SHA256SUMS"
    $assetPath = Join-Path $temporaryDir $asset
    Invoke-WebRequest -UseBasicParsing -Uri "$releaseBase/SHA256SUMS" -OutFile $checksumsPath
    $checksumsHash = (Get-FileHash $checksumsPath -Algorithm SHA256).Hash.ToLowerInvariant()
    if ($checksumsHash -ne $pinnedChecksumsSha256) {
        throw "SHA256SUMS 与 Skill 锁定值不一致。"
    }
    $checksumLine = Get-Content $checksumsPath | Where-Object { $_ -match "\s+$([Regex]::Escape($asset))$" } | Select-Object -First 1
    if ([string]::IsNullOrWhiteSpace($checksumLine)) {
        throw "校验清单中没有 Windows 制品。"
    }
    $expectedHash = ($checksumLine -split '\s+')[0].ToLowerInvariant()
    Invoke-WebRequest -UseBasicParsing -Uri "$releaseBase/$asset" -OutFile $assetPath
    $actualHash = (Get-FileHash $assetPath -Algorithm SHA256).Hash.ToLowerInvariant()
    if ($actualHash -ne $expectedHash) {
        throw "$asset 的 SHA-256 校验失败。"
    }
    $metadata = (& $assetPath version --format json 2>$null) -join ""
    if ($LASTEXITCODE -ne 0 -or -not $metadata.Contains("`"commit`":`"$pinnedCommit`"")) {
        throw "二进制的版本或上游提交验证失败。"
    }
    New-Item -ItemType Directory -Force -Path $normalizedInstallDir | Out-Null
    $stagedTarget = Join-Path $normalizedInstallDir ".weknora.new.$PID"
    Copy-Item -Force $assetPath $stagedTarget
    & $stagedTarget version --format json *> $null
    if ($LASTEXITCODE -ne 0) { throw "安装前的最终冒烟验证失败。" }
    Move-Item -Force $stagedTarget $target
}
finally {
    Remove-Item -Recurse -Force $temporaryDir -ErrorAction SilentlyContinue
}

Write-Output "cli_path=$target"
Write-Output "installed=cnb_release"
Write-Output "release_tag=$pinnedReleaseTag"
