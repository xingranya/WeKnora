#!/usr/bin/env bash

set -euo pipefail

readonly PINNED_COMMIT="7f11b7b5b9bb"
readonly PINNED_RELEASE_TAG="cli-main-7f11b7b5b9bb-1"
readonly PINNED_CHECKSUMS_SHA256="4f818b55f18b575c9e3833955058b768bcfa25ea2c50ea6df81631523e285226"
readonly DEFAULT_RELEASE_BASE="https://cnb.cool/xingranya/weknora-cli/-/releases/download/$PINNED_RELEASE_TAG"
readonly DEFAULT_INSTALL_DIR="$HOME/.local/bin"

release_base="${WEKNORA_CLI_RELEASE_BASE_URL:-$DEFAULT_RELEASE_BASE}"
install_dir="${WEKNORA_CLI_INSTALL_DIR:-$DEFAULT_INSTALL_DIR}"
temporary_dir=""
staged_target=""

cleanup() {
  [[ -z "$staged_target" ]] || rm -f "$staged_target"
  [[ -z "$temporary_dir" ]] || rm -rf "$temporary_dir"
}

fail() {
  printf 'WeKnora CLI 安装失败：%s\n' "$1" >&2
  exit 1
}

sha256_file() {
  if command -v sha256sum >/dev/null 2>&1; then
    sha256sum "$1" | awk '{print $1}'
  elif command -v shasum >/dev/null 2>&1; then
    shasum -a 256 "$1" | awk '{print $1}'
  else
    fail "缺少 sha256sum 或 shasum。"
  fi
}

trap cleanup EXIT

[[ "$release_base" == https://* ]] || fail "下载地址必须使用 HTTPS。"
[[ "$install_dir" == /* ]] || fail "安装目录必须是绝对路径。"
command -v curl >/dev/null 2>&1 || fail "缺少 curl。"

target="$install_dir/weknora"
if [[ -e "$target" || -L "$target" ]]; then
  [[ ! -d "$target" ]] || fail "目标路径是目录，拒绝替换：$target"
  if [[ -x "$target" ]]; then
    current_metadata="$($target version --format json 2>/dev/null || true)"
    if [[ "$current_metadata" == *"\"commit\":\"$PINNED_COMMIT\""* ]]; then
      printf 'cli_path=%s\n' "$target"
      printf 'installed=reused\n'
      exit 0
    fi
  fi
  [[ "${WEKNORA_CLI_REPLACE:-0}" == 1 ]] \
    || fail "目标路径已存在且不是锁定版本：${target}。未经明确授权不自动覆盖；确认后设置 WEKNORA_CLI_REPLACE=1。"
fi

case "$(uname -s)" in
  Darwin) os_name="darwin" ;;
  Linux) os_name="linux" ;;
  *) fail "当前系统不受此脚本支持；Windows 请用 PowerShell 安装器。" ;;
esac

case "$(uname -m)" in
  arm64|aarch64) arch_name="arm64" ;;
  x86_64|amd64) arch_name="amd64" ;;
  *) fail "不支持当前 CPU 架构：$(uname -m)" ;;
esac

asset="weknora-${os_name}-${arch_name}"
temporary_dir="$(mktemp -d "${TMPDIR:-/tmp}/weknora-cli-install.XXXXXX")"
checksums_path="$temporary_dir/SHA256SUMS"
asset_path="$temporary_dir/$asset"

curl --silent --show-error --fail --location --proto '=https' --tlsv1.2 \
  --connect-timeout 15 --max-time 60 \
  "$release_base/SHA256SUMS" --output "$checksums_path"
[[ "$(sha256_file "$checksums_path")" == "$PINNED_CHECKSUMS_SHA256" ]] \
  || fail "SHA256SUMS 与 Skill 锁定值不一致。"

expected_sha="$(awk -v asset="$asset" '$2 == asset {print $1; exit}' "$checksums_path")"
[[ "$expected_sha" =~ ^[0-9a-f]{64}$ ]] || fail "校验清单中没有当前平台制品。"

curl --silent --show-error --fail --location --proto '=https' --tlsv1.2 \
  --connect-timeout 15 --max-time 300 \
  "$release_base/$asset" --output "$asset_path"
[[ "$(sha256_file "$asset_path")" == "$expected_sha" ]] \
  || fail "$asset 的 SHA-256 校验失败。"

chmod 0755 "$asset_path"
"$asset_path" version --format json >/dev/null 2>&1 \
  || fail "下载制品不能正常执行 version。"
metadata="$($asset_path version --format json)"
[[ "$metadata" == *"\"commit\":\"$PINNED_COMMIT\""* ]] \
  || fail "二进制上游提交与 Skill 锁定值不一致。"

if [[ "$os_name" == darwin ]]; then
  command -v codesign >/dev/null 2>&1 || fail "macOS 缺少 codesign。"
  codesign -v --strict "$asset_path" 2>/dev/null \
    || fail "macOS 制品的 ad-hoc 签名验证失败。"
fi

mkdir -p "$install_dir"
staged_target="$install_dir/.weknora.new.$$"
install -m 0755 "$asset_path" "$staged_target"
"$staged_target" version --format json >/dev/null 2>&1 \
  || fail "安装前的最终冒烟验证失败。"
mv -f "$staged_target" "$target"
staged_target=""

printf 'cli_path=%s\n' "$target"
printf 'installed=cnb_release\n'
printf 'release_tag=%s\n' "$PINNED_RELEASE_TAG"
