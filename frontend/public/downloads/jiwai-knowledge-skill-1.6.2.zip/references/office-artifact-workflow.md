# 知识库取材与 OfficeCLI 产物工作流

仅在用户要求“基于见外知识库中指定知识库或文件夹的资料”新建、重写、修正 Word，或新建、修改、计算 Excel 时读取本文件。

## 职责边界

- WeKnora 负责：确定知识范围、列出资料、限定检索、下载原文件、保留来源和内部 ID。
- OfficeCLI 负责：检查、修改、保存和验证真实 `.docx` / `.xlsx` 文件。
- Agent 负责：事实与目标映射、冲突判断、用户检查点、变更清单和最终验收。
- 默认不把修改后的文件回传知识库；用户明确要求回传时，重新进入上传确认流程。

## 前置检查

1. 读取并遵守 `officecli` skill。`officecli --version` 必须在 `>=1.0.144,<2.0.0`；否则停止并说明升级或大版本兼容问题。
2. Word 使用 `officecli load_skill word`；普通 Excel 使用 `officecli load_skill excel`；财务模型或仪表盘仅在任务明确匹配时选择更具体专项。
3. 每个 Office 文件只加载一个最具体专项，不能叠加多个专项。
4. 当 Skill 与实际帮助不一致时，以当前 `officecli help <format> ...` 为命令、属性和返回字段的最终权威。
5. 关闭 Word、Excel、WPS 中正在打开的目标文件，避免文件锁和外部覆盖。
6. 使用独立工作目录和新输出文件名，禁止直接编辑下载缓存或原始文件。

## 通用流程

### 1. 锁定知识范围

- 精确解析知识库名称；0 个或多个同名候选都停止。
- 调用文件夹树接口定位用户指定文件夹。
- 使用 `folder_path` 和 `folder_recursive` 限定资料范围；不得扩大到整个知识库。
- 分页取完文件夹内知识条目，记录 `total` 并设置最大页数保护。

### 2. 建立文件清单

为每个条目记录：

```json
{
  "knowledge_id": "仅内部使用",
  "title": "用户可见名称",
  "file_name": "原文件名",
  "file_type": "docx|pdf|xlsx|md|...",
  "folder_path": "用户指定范围内路径",
  "parse_status": "completed",
  "processed_at": "服务端时间",
  "role": "evidence|target|both"
}
```

- `parse_status` 不是 `completed` 的资料默认不作为最终事实来源；确需使用时标记局限。
- 明确区分参考资料与待修改目标。目标文件未唯一确定时先询问用户。

### 3. 获取证据与真实原文件

- 主题取材：优先对文件夹清单得到的 `knowledge_ids` 做限定检索，避免越界命中其他目录。
- 数字、金额、日期、参数、公式规则：优先下载原始文档或工作簿核对，不能只依赖分块摘要。
- 修改 DOCX/XLSX：必须下载目标原文件；`GET /knowledge/:id` 的元数据不能替代原文件。
- 下载写入新的本地路径，并计算 SHA-256；记录来源文件、版本时间和相关章节/页码/工作表/单元格。
- 对证据 DOCX/XLSX 执行 `view/get/query/validate` 时设置 `OFFICECLI_NO_AUTO_RESIDENT=1`；只读取证后再计算 SHA-256，必须与下载值一致。
- 原文件无法取得时停止真实 Office 修改，只能报告“未取得原件”，不能生成冒充原件的文件。

### 4. 形成知识交接包

在调用 OfficeCLI 前形成：

```json
{
  "scope": {
    "knowledge_base": "显示名称",
    "folder_path": "项目资料/当前任务",
    "recursive": true
  },
  "source_documents": [
    {
      "title": "合同.docx",
      "local_path": "/absolute/path/合同.docx",
      "sha256": "...",
      "relevant_locations": ["第4章", "表2"],
      "facts": [],
      "rules": []
    }
  ],
  "target_artifact": {
    "mode": "create|edit",
    "input_path": "/absolute/path/input.docx 或 create 时为 null",
    "output_path": "/absolute/path/input-修订版.docx",
    "allowed_scope": "第3章或新建产物的结构大纲"
  },
  "verified_facts": [],
  "constraints": [],
  "conflicts": [],
  "unknowns": [],
  "requested_edits": [],
  "acceptance_checks": []
}
```

规则：

- 用户明确输入优先于推断；资料之间冲突时不得自行选一条。
- 检索排名只用于找到候选证据，不决定事实权威性。
- 无法映射到目标章节、段落、工作表、行、列或单元格的值不得写入。

### 5. OfficeCLI 执行共性

1. 编辑模式复制原文件为新输出文件；新建模式要求输出路径不存在，再运行
   `officecli create <output> --locale zh-CN --json`。正式 Word 报告不使用 `--minimal`，未获覆盖授权不使用 `create --force`。
2. 先对原件执行无驻留只读检查：`OFFICECLI_NO_AUTO_RESIDENT=1 officecli view ...`、
   `get --json`、`query --json`、`validate --json`。检查前后 SHA-256 不一致则停止。
3. 编辑前运行 `view outline`、`view stats`、`view issues --json`，再用 `get/query --json` 定位；
   不猜路径、属性或枚举，拿不准时运行当前 `officecli help`。
4. 优先 L1 读取与 L2 DOM 修改；只有 L2 无法表达时才使用 raw XML。
5. 知识驱动的多项写入使用 OfficeCLI 1.0.144 默认原子 `batch --json`；可加 `--stop-on-error`
   提前终止后续项，但它不决定是否回滚。禁止 `--best-effort`，除非用户明确接受容错性 `dump → batch` 部分结果。
6. batch 前记录输出文件 SHA-256。任一项失败时要求非零退出、
   `summary.atomicRolledBack=true`、每个失败项存在 `code`，且 batch 后 SHA-256 与之前一致；任一门不通过就废弃输出副本。
7. 长流程可 `officecli open`，完成后 `save` 或 `close`；在非 OfficeCLI 程序读取、渲染、哈希、上传或交付前必须 flush。
8. `validate --json` 只负责 OpenXML 结构；`view issues --json` 负责内容/公式/缓存/断引用问题；
   业务事实和数值另行与知识交接包复核。三者不可互相替代。
9. Word 先生成 `view ... html -o <preview.html>`；可视检查时再执行
   `view ... screenshot --grid auto -o <contact-sheet.png>` 并目检全部页面。Excel 用 HTML 逐个工作表检查 `###`、截断、占位符、公式和图表。
10. 最终报告真实完成状态，不能把计划、标记或文本建议说成已创建或修改文件。

## 模式 A：基于知识库新建 Word 报告或 Excel 工作簿

1. Word 和 Excel 是两个独立产物；分别加载 `word` 与 `excel` 专项，不在同一文件上叠加专项。
2. 目标路径必须不存在；使用 `officecli create <output> --locale zh-CN --json`。
   普通正式 Word 报告不使用 `--minimal`，未获覆盖授权不使用 `--force`。
3. 先在知识交接包中固定大纲、来源映射、已验证事实、分析性推断、冲突和未知项；产物中不把推断写成知识库原文。
4. Word 报告至少包含标题层级、范围/方法、核心结论、来源与未知项；关键事实标注来源文件和可定位位置。
5. Excel 工作簿应根据任务划分数据、映射、统计或来源工作表；可计算值使用公式，不用常量冒充计算结果。
6. `create` 成功后的多项写入使用默认原子 batch，并执行与编辑任务相同的结构、issues、视觉、事实和数值验收。
7. 交付新文件、内容/公式摘要、来源清单、验收结果、冲突和未知项。

## 模式 B：重写 Word 指定内容

1. 用 outline 和稳定 ID 定位用户指定章节；章节不唯一时停止。
2. 冻结知识包中的项目名、日期、金额、人员、技术参数和承诺等已验证事实。
3. 只重写允许范围；不改页眉页脚、目录、图片、表格、脚注、批注和其他章节。
4. 对知识库没有依据的新增事实不写入；来源冲突写入 `conflicts` 并请求选择。
5. 使用 OfficeCLI Word 专项执行最小 DOM 修改；需要审阅痕迹时使用修订或评论能力。
6. 修改后验证：目标章节内容、未授权区域差异、目录/字段、图片与表格、分页和版式。
7. 交付：新 DOCX、改写摘要、来源清单、验证结果、冲突和未知项。

## 模式 C：修正 Word 指定内容

先建立修正判定表：

| 状态 | 动作 |
|---|---|
| 已验证错误 | 自动修正，并记录原文、修正、依据 |
| 多来源一致 | 可作为确定事实 |
| 来源冲突 | 不改，列出候选和来源 |
| 知识库无依据 | 不改，标记“无依据” |
| 可能过期 | 不改或添加评论，等待确认 |

执行要求：

1. 只修改用户指定范围内的已验证错误，不把润色混入事实修正。
2. 使用稳定路径定位段落/表格；需人工复核的内容优先以评论或修订呈现。
3. 变更清单必须与实际 DOCX 修改一一对应。
4. 验收时反向核对：清单中的每项修改都存在，未列出的内容没有意外变化。

## 模式 D：修改 Excel 并计算

### 读取与映射

1. 读取工作表、命名区域、表格、隐藏行列、合并单元格、公式、数据验证、外部链接、宏和透视表信息。
2. 建立“知识来源字段 → 工作表/行/列/单元格”映射表，并记录单位、币种、生效范围和来源。
3. 以下任一不明确时停止相关写入：含税/未税、折扣先后顺序、工作日/自然日、人天口径、角色到行的映射、四舍五入规则。

### 修改

1. 只修改确认过的输入项和必要公式；不得用计算结果常量替换原公式，除非用户明确要求。
2. 使用 OfficeCLI Excel 专项和 batch 原子化执行；任一操作失败即停止。
3. 保留无关工作表、格式、批注、合并单元格、列宽、数据验证、命名区域和公式引用。
4. 公式能力不确定时运行 `officecli help xlsx`，不得猜测属性或函数支持。

### 计算与验收

- 查询全部公式单元格，用 `get --json` 核对 `formula`、`cachedValue`、`computedValue` 和 `evaluated`；
  汇总单元格的缓存值必须合理，不能因 `validate` 通过就默认计算正确。
- 执行 `view issues --type content --json`，将 `formula_not_evaluated`、`formula_cache_stale`、
  `formula_ref_missing_sheet`、`formula_eval_error`、`definedname_broken` 和 `definedname_target_missing` 视为阻断问题。
- 遇到 `SUBTOTAL` 时同时检查函数号、AutoFilter 与手动隐藏行：`1–11` 忽略筛选隐藏行，`101–111` 忽略全部隐藏行。
- 空值比较必须区分未存在单元格、`empty=true`、文本空串、公式空串和只带样式的空单元格；
  XLSX `view text` 会省略空单元格，不得用“没显示”推断其类型。
- 日期/时间格式文本参与算术时，记录原单元格 `type`、`numberformat` 和预期 Excel 序列值，再对照 `computedValue`。
- 独立复算关键值：数量 × 天数 × 单价、小计、折扣、税额、含税总计和汇总；同时检查单位/币种、逐行与总额舍入差异。
- 比较输入与输出，确保无关工作表和未授权区域没有变化。
- 宏、外部数据源或 OfficeCLI 不支持的公式必须列入“未验证范围”，不得声称完全验收。
- 交付：新 XLSX、单元格变更清单、公式清单、来源依据、复算结果和未解决映射。

## 停止条件

出现以下任一情况时停止对应修改，但保留已完成的只读证据盘点：

- 知识库、文件夹或目标文件不唯一；
- 用户指定范围无法通过当前 API 严格限定；
- 目标 Office 原文件无法下载；
- 关键事实来源冲突或缺失；
- Excel 字段到单元格映射不明确；
- OfficeCLI 缺失、文件被锁、校验失败或输出文件已存在；
- OfficeCLI 不在 `>=1.0.144,<2.0.0`，证据原件只读前后 SHA-256 变化，或 batch 失败时无法证明原子回滚；
- Excel 存在未解决的公式未计算、缓存过期、断引用、定义名称失效或 1.0.144 计算边界语义冲突；
- 修改需要扩大用户授权范围；
- 用户要求回传知识库但未明确目标、文件名和新增/覆盖语义。

## 最终输出契约

```text
实际状态：完成 / 部分完成 / 阻塞
本地文件：绝对路径
创建/修改范围：报告结构、章节、段落、工作表或单元格
主要创建/变更：简要列表
知识来源：文件名 + 相关位置
验证结果：原件字节保持、原子 batch、结构、issues、版式、公式、缓存、数值、无关区域
冲突与未知项：逐项列出
知识库写入：无 / 已明确授权并完成
```
