[CmdletBinding()]
param()

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

$installerUrl = "https://d.officecli.ai/install.ps1"
$installerSha256 = "ef24f389b27bc5a85142b1d414f3d25047aa62c5188d9b9789940435b22b6c45"
$existing = Get-Command officecli -ErrorAction SilentlyContinue
if ($existing) {
    $currentVersionText = ((& $existing.Source --version 2>$null) -join "").Trim()
    $parsedVersion = $null
    if ($LASTEXITCODE -eq 0 -and [Version]::TryParse($currentVersionText, [ref]$parsedVersion) -and $parsedVersion -ge [Version]"1.0.135") {
        Write-Output "officecli_path=$($existing.Source)"
        Write-Output "officecli_installed=reused"
        Write-Output "officecli_version=$currentVersionText"
        exit 0
    }
    if ($env:OFFICECLI_REPLACE -ne "1") {
        throw "OfficeCLI 安装失败：已有版本低于 1.0.135 或无法解析；确认升级后设置 OFFICECLI_REPLACE=1。"
    }
}

$temporaryDir = Join-Path ([IO.Path]::GetTempPath()) ("officecli-install-" + [Guid]::NewGuid().ToString("N"))
New-Item -ItemType Directory -Path $temporaryDir | Out-Null
try {
    $installerPath = Join-Path $temporaryDir "install.ps1"
    Invoke-WebRequest -UseBasicParsing -Uri $installerUrl -OutFile $installerPath
    $actualHash = (Get-FileHash $installerPath -Algorithm SHA256).Hash.ToLowerInvariant()
    if ($actualHash -ne $installerSha256) {
        throw "OfficeCLI 官方安装脚本与 Skill 锁定的 SHA-256 不一致，请先更新 Skill。"
    }
    & powershell -NoProfile -ExecutionPolicy Bypass -File $installerPath
    if ($LASTEXITCODE -ne 0) { throw "OfficeCLI 官方安装脚本执行失败。" }
}
finally {
    Remove-Item -Recurse -Force $temporaryDir -ErrorAction SilentlyContinue
}

$existing = Get-Command officecli -ErrorAction SilentlyContinue
if (-not $existing) {
    $fallbackPath = Join-Path $HOME ".local\bin\officecli.exe"
    if (Test-Path $fallbackPath -PathType Leaf) { $existing = Get-Item $fallbackPath }
}
if (-not $existing) { throw "OfficeCLI 安装后仍不可用。" }
$officecliPath = if ($existing.PSObject.Properties.Name -contains "Source") { $existing.Source } else { $existing.FullName }
& $officecliPath --version *> $null
if ($LASTEXITCODE -ne 0) { throw "OfficeCLI 安装后版本验证失败。" }
$installedVersionText = ((& $officecliPath --version 2>$null) -join "").Trim()
$installedVersion = $null
if (-not [Version]::TryParse($installedVersionText, [ref]$installedVersion) -or $installedVersion -lt [Version]"1.0.135") {
    throw "OfficeCLI 安装版本低于 1.0.135。"
}

Write-Output "officecli_path=$officecliPath"
Write-Output "officecli_installed=official_installer"
Write-Output "officecli_version=$installedVersionText"
