---
name: weknora
description: >
  通过见外知识库（WeKnora）API 自动配置访问凭据、导入文件、网页或 Markdown，并执行知识库浏览、
  详情查询和混合检索。适用于首次使用时在 macOS 或 Windows 上配置
  WEKNORA_BASE_URL 与 WEKNORA_API_KEY，以及后续上传资料、查询解析进度、
  单知识库检索或跨知识库检索。
---

# 见外知识库

通过见外知识库 REST API 配置访问凭据、导入资料和检索知识。

## 执行顺序

1. 在任何 API 请求前执行“凭据检查”。
2. 凭据缺失时执行“首次运行与自动配置”，不要要求用户手动编辑环境变量。
3. 配置成功后执行一次只读验证，再继续用户原本的任务。
4. 涉及编辑、删除或覆盖数据时，先向用户确认明确目标。

## 凭据检查

- 检查当前进程中的 `WEKNORA_BASE_URL` 和 `WEKNORA_API_KEY` 是否均为非空。
- Windows 当前进程未读到变量时，再检查用户级环境变量；这是已持久化但当前 AI
  进程尚未继承新变量的正常情况。
- 只报告“已配置”或“未配置”。禁止输出、记录或拼接完整 API Key。
- 两项均存在时直接复用，不重复询问用户，也不覆盖已有配置。

## 首次运行与自动配置

### 1. 向用户索取凭据

任一变量缺失时，向用户发送以下含义的简短提示，然后等待回复：

> 请在见外知识库的“设置 > API 集成 > API Keys”中点击“复制”，把完整 API Key
> 发给我。不要发送页面中带星号的缩略值。默认 API 地址是
> `https://know.seeway.co/api/v1`；如果你使用其他部署地址，请一并发送。

同时遵守以下要求：

- 建议用户创建满足当前任务的最小权限 Key。
- 将用户消息中的完整 Key 视为密钥；之后的命令输出和回复都只能使用脱敏值。
- Key 为空、含空白、含 `*` 或不是 `sk-` 开头时不要写入，重新索取完整 Key。
- 不把 Key 写入项目、由 AI 自行创建的临时文件、脚本参数、提交记录或最终回复。
  macOS 配置脚本内部用于原子更新的临时文件会在完成后立即删除。

### 2. 由 AI 自动写入用户环境

收到有效 Key 后先识别操作系统，再由 AI 执行本 skill 自带脚本。不要把命令交给
用户执行。通过交互式标准输入传入 Key，禁止把 Key 放进命令行参数。

macOS：

```bash
bash "<skill目录>/scripts/configure_macos_env.sh" "https://know.seeway.co/api/v1"
```

脚本提示输入时，将用户提供的 Key 写入标准输入。脚本根据默认 shell 更新：

- zsh：`~/.zprofile`
- bash：`~/.bash_profile`
- 其他 shell：`~/.profile`

脚本只替换见外知识库的受管区块，不修改其他配置，并将配置文件权限设为
仅当前用户可读写。

Windows：

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File "<skill目录>\scripts\configure_windows_env.ps1" -BaseUrl "https://know.seeway.co/api/v1"
```

已安装 PowerShell 7 时也可使用 `pwsh`。脚本提示输入时，将用户提供的 Key 写入
标准输入。脚本通过 Windows 用户级环境变量持久化配置，并通知系统环境已更新。

若用户提供了自定义 API 地址，用该地址替换示例中的默认地址。脚本失败时报告具体
错误并停止，不要反复执行同一失败命令。

### 3. 脱敏验证

配置脚本成功后验证以下两项，不输出变量原值：

1. `WEKNORA_BASE_URL` 与 `WEKNORA_API_KEY` 在持久化位置均非空。
2. 使用新凭据调用一次 `GET /knowledge-bases?page=1&page_size=1`。

若返回 `401`，说明 Key 无效，重新索取完整 Key；若返回 `403`，说明 Key 权限不足，
提示用户创建具备所需只读或写入权限的 Key。验证成功后只回复 API 地址、操作系统、
“凭据已配置”和验证结果，Key 最多显示末四位。

Windows 配置后的当前 AI 进程可能尚未继承新变量。继续当前任务时，从用户级环境变量
读取到当前 PowerShell 进程，不要求用户重启：

```powershell
$env:WEKNORA_BASE_URL = [Environment]::GetEnvironmentVariable("WEKNORA_BASE_URL", "User")
$env:WEKNORA_API_KEY = [Environment]::GetEnvironmentVariable("WEKNORA_API_KEY", "User")
```

环境变量本身不是加密存储。只在用户授权的本机环境配置，并避免在共享设备上使用
高权限 Key。

## API 请求模板

所有请求均使用 `$WEKNORA_BASE_URL` 和统一请求头。macOS/Linux shell 中定义：

```bash
wk_api() {
  local method="$1" endpoint="$2" body="${3:-}"
  local args=(
    -sS -X "$method" "$WEKNORA_BASE_URL/$endpoint"
    -H "X-API-Key: $WEKNORA_API_KEY"
    -H "Content-Type: application/json"
    -H "X-Request-ID: $(uuidgen 2>/dev/null || date +%s)"
  )
  if [[ -n "$body" ]]; then
    args+=(-d "$body")
  fi
  curl "${args[@]}"
}
```

上传文件时直接使用 `curl -F`，不要手动设置 `Content-Type`。

## API 选择表

| 用户意图 | 接口 | 关键参数 |
|---|---|---|
| 列出知识库 | `GET /knowledge-bases` | 无 |
| 查看知识库详情 | `GET /knowledge-bases/:id` | 无 |
| 上传文件 | `POST /knowledge-bases/:id/knowledge/file` | `file`、`enable_multimodel` |
| 导入网页 | `POST /knowledge-bases/:id/knowledge/url` | `url`、`enable_multimodel` |
| 写入 Markdown | `POST /knowledge-bases/:id/knowledge/manual` | `title`、`content`、`tag_id` |
| 查询解析进度 | `GET /knowledge/:id` | 检查 `parse_status` |
| 浏览知识库内容 | `GET /knowledge-bases/:id/knowledge` | `page`、`page_size`、`tag_id` |
| 编辑 Markdown 知识 | `PUT /knowledge/manual/:id` | `title`、`content` |
| 删除知识条目 | `DELETE /knowledge/:id` | 无 |
| 在单个知识库检索 | `GET /knowledge-bases/:id/hybrid-search` | `query_text`、`match_count`、阈值 |
| 跨知识库检索 | `POST /knowledge-search` | `query`、`knowledge_base_ids` |

## 常用流程

### 上传文件并等待解析

```bash
# 1. 查找目标知识库
wk_api GET "knowledge-bases"

# 2. 上传文件，并从 data.id 取得 knowledge_id
curl -sS -X POST "$WEKNORA_BASE_URL/knowledge-bases/<kb_id>/knowledge/file" \
  -H "X-API-Key: $WEKNORA_API_KEY" \
  -F 'file=@document.pdf' -F 'enable_multimodel=true'

# 3. 轮询，直到 data.parse_status 为 completed 或 failed
wk_api GET "knowledge/<knowledge_id>"
```

### 导入网页

```bash
wk_api POST "knowledge-bases/<kb_id>/knowledge/url" \
  '{"url":"https://example.com/article","enable_multimodel":true}'
```

成功后按文件上传流程轮询 `knowledge/:id`。

### 写入 Markdown

```bash
wk_api POST "knowledge-bases/<kb_id>/knowledge/manual" \
  '{"title":"会议记录","content":"# 第一季度复盘\n\n关键事项……"}'
```

### 检索知识

```bash
# 单知识库混合检索
wk_api GET "knowledge-bases/<kb_id>/hybrid-search" \
  '{"query_text":"部署流程","match_count":5}'

# 跨知识库语义检索
wk_api POST "knowledge-search" \
  '{"query":"部署流程","knowledge_base_ids":["kb-1","kb-2"]}'
```

### 浏览和读取内容

```bash
wk_api GET "knowledge-bases/<kb_id>/knowledge?page=1&page_size=20"
wk_api GET "knowledge/<knowledge_id>"
```

## 核心响应字段

- 知识库：`data[]` 中包含 `id`、`name`、`description`、`type`、
  `embedding_model_id`、`knowledge_count`、`chunk_count`、`is_processing`、
  `created_at`。
- 知识条目：`data` 中包含 `id`、`title`、`description`、`type`、
  `parse_status`、`enable_status`、`file_name`、`file_type`、`file_size`、
  `source`、`created_at`、`processed_at`、`error_message`。
- 检索结果：`data[]` 中包含 `id`、`content`、`score`、`knowledge_id`、
  `knowledge_title`、`knowledge_filename`、`chunk_index`、`chunk_type`、
  `match_type`、`metadata`。
- 分页列表：返回 `data[]`、`total`、`page`、`page_size`。

## 状态与分页

- `parse_status`：`pending` -> `processing` -> `completed` 或 `failed`。
- `enable_status`：解析成功后由 `disabled` 自动变为 `enabled`。
- 知识 `type`：`file`、`url`、`manual`。
- 知识库 `type`：`document`、`faq`。
- `chunk_type`：`text`、`summary`、`image`。
- 列表接口使用 `page` 和 `page_size`；用响应中的 `total` 计算总页数。
- 混合检索最多返回 `match_count` 条，不使用分页。

## 注意事项

- `GET /knowledge-bases/:id/hybrid-search` 使用 GET，但请求参数放在 JSON body 中。
- 文件上传使用 `multipart/form-data`；不要使用 JSON 请求体。
- `file_type` 由服务端自动识别，支持 `pdf`、`docx`、`xlsx`、`pptx`、
  `txt`、`md`、`csv`、`html` 等格式。
- `score` 范围为 0 到 1，越高越相关；可调整 `vector_threshold` 过滤低质量结果。
- `parse_status` 为 `failed` 时先读取 `error_message`，再决定是否调用
  `POST /knowledge/:id/reparse`。

## 错误处理

错误响应格式：

```json
{
  "success": false,
  "error": {
    "code": "ERROR_CODE",
    "message": "错误说明",
    "details": "可选详细信息"
  }
}
```

| HTTP 状态码 | 含义 | 处理方式 |
|---|---|---|
| `400` | 请求错误 | 检查必填字段和参数格式 |
| `401` | 认证失败 | 重新验证 `WEKNORA_API_KEY` |
| `403` | 权限不足 | 检查 Key 的操作权限和知识库范围 |
| `404` | 资源不存在 | 检查资源 ID |
| `413` | 文件过大 | 缩小文件或拆分内容 |
| `500` | 服务端错误 | 稍后重试一次；仍失败则报告响应内容 |
