﻿[CmdletBinding()]
param(
    [string]$BaseUrl = "https://know.seeway.co/api/v1"
)

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

function Test-IsWindows {
    if ($PSVersionTable.PSVersion.Major -ge 6) {
        return $IsWindows
    }
    return $env:OS -eq "Windows_NT"
}

function Read-WeKnoraApiKey {
    if ([Console]::IsInputRedirected) {
        return [Console]::In.ReadLine()
    }

    $secureKey = Read-Host "请输入完整见外知识库 API Key（输入不会显示）" -AsSecureString
    $keyPointer = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($secureKey)
    try {
        return [Runtime.InteropServices.Marshal]::PtrToStringBSTR($keyPointer)
    }
    finally {
        [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($keyPointer)
    }
}

function Send-EnvironmentChangedNotification {
    try {
        if (-not ("WeKnora.EnvironmentBroadcast" -as [type])) {
            Add-Type -TypeDefinition @"
using System;
using System.Runtime.InteropServices;

namespace WeKnora {
    public static class EnvironmentBroadcast {
        [DllImport("user32.dll", SetLastError = true, CharSet = CharSet.Auto)]
        public static extern IntPtr SendMessageTimeout(
            IntPtr windowHandle,
            uint message,
            UIntPtr wordParameter,
            string longParameter,
            uint flags,
            uint timeout,
            out UIntPtr result
        );
    }
}
"@
        }

        $broadcastHandle = [IntPtr]0xffff
        $settingChanged = 0x001A
        $abortIfHung = 0x0002
        $broadcastResult = [UIntPtr]::Zero
        [void][WeKnora.EnvironmentBroadcast]::SendMessageTimeout(
            $broadcastHandle,
            $settingChanged,
            [UIntPtr]::Zero,
            "Environment",
            $abortIfHung,
            5000,
            [ref]$broadcastResult
        )
    }
    catch {
        Write-Warning "环境变量已写入，但系统更新通知失败：$($_.Exception.Message)"
    }
}

if (-not (Test-IsWindows)) {
    throw "此脚本只能在 Windows 上运行。"
}

$normalizedBaseUrl = $BaseUrl.Trim().TrimEnd([char[]]"/")
if ($normalizedBaseUrl -notmatch '^https?://[^\s]+$') {
    throw "API 地址必须以 http:// 或 https:// 开头，且不能包含空白字符。"
}

$apiKey = Read-WeKnoraApiKey
if ([string]::IsNullOrWhiteSpace($apiKey)) {
    throw "API Key 不能为空。"
}
if (-not $apiKey.StartsWith("sk-")) {
    throw "API Key 必须以 sk- 开头。"
}
if ($apiKey.Length -lt 8) {
    throw "API Key 长度过短，请提供完整 Key。"
}
if ($apiKey.Contains("*")) {
    throw "不能使用页面中带星号的缩略 Key。"
}
if ($apiKey -match '\s') {
    throw "API Key 不能包含空白字符。"
}

[Environment]::SetEnvironmentVariable("WEKNORA_BASE_URL", $normalizedBaseUrl, "User")
[Environment]::SetEnvironmentVariable("WEKNORA_API_KEY", $apiKey, "User")

$savedBaseUrl = [Environment]::GetEnvironmentVariable("WEKNORA_BASE_URL", "User")
$savedApiKey = [Environment]::GetEnvironmentVariable("WEKNORA_API_KEY", "User")
if ($savedBaseUrl -ne $normalizedBaseUrl -or $savedApiKey -ne $apiKey) {
    throw "用户级环境变量写入后校验失败。"
}

Send-EnvironmentChangedNotification

$keySuffix = $apiKey.Substring([Math]::Max(0, $apiKey.Length - 4))
Write-Output "见外知识库环境变量已配置。"
Write-Output "作用范围：Windows 当前用户"
Write-Output "API 地址：$normalizedBaseUrl"
Write-Output "API Key：****$keySuffix"
Write-Output "当前任务可从用户级环境变量重新加载，完整 Key 不会显示。"

$apiKey = $null
$savedApiKey = $null
