#!/bin/bash

set -euo pipefail

readonly DEFAULT_BASE_URL="https://know.seeway.co/api/v1"
readonly BLOCK_BEGIN="# >>> WeKnora skill managed environment >>>"
readonly BLOCK_END="# <<< WeKnora skill managed environment <<<"

temporary_file=""
tty_echo_disabled=0

cleanup() {
  if [[ "$tty_echo_disabled" -eq 1 ]]; then
    stty echo 2>/dev/null || true
  fi
  if [[ -n "$temporary_file" ]]; then
    rm -f "$temporary_file"
  fi
}

fail() {
  printf '配置失败：%s\n' "$1" >&2
  exit 1
}

trap cleanup EXIT

base_url="${1:-$DEFAULT_BASE_URL}"
base_url="${base_url%/}"
[[ "$base_url" == http://* || "$base_url" == https://* ]] \
  || fail "API 地址必须以 http:// 或 https:// 开头。"
[[ "$base_url" != *[[:space:]]* ]] || fail "API 地址不能包含空白字符。"

if [[ -t 0 ]]; then
  printf '请输入完整见外知识库 API Key（输入不会显示）：' >&2
  stty -echo
  tty_echo_disabled=1
  IFS= read -r api_key || fail "未读取到 API Key。"
  stty echo
  tty_echo_disabled=0
  printf '\n' >&2
else
  IFS= read -r api_key || fail "未从标准输入读取到 API Key。"
fi

[[ -n "$api_key" ]] || fail "API Key 不能为空。"
[[ "$api_key" == sk-* ]] || fail "API Key 必须以 sk- 开头。"
[[ "${#api_key}" -ge 8 ]] || fail "API Key 长度过短，请提供完整 Key。"
[[ "$api_key" != *'*'* ]] || fail "不能使用页面中带星号的缩略 Key。"
[[ "$api_key" != *[[:space:]]* ]] || fail "API Key 不能包含空白字符。"

if [[ -n "${WEKNORA_PROFILE_PATH:-}" ]]; then
  profile_path="$WEKNORA_PROFILE_PATH"
else
  shell_name="$(basename "${SHELL:-/bin/zsh}")"
  case "$shell_name" in
    zsh) profile_path="$HOME/.zprofile" ;;
    bash) profile_path="$HOME/.bash_profile" ;;
    *) profile_path="$HOME/.profile" ;;
  esac
fi

profile_directory="$(dirname "$profile_path")"
[[ -d "$profile_directory" ]] || fail "配置目录不存在：$profile_directory"

if [[ -f "$profile_path" ]]; then
  if ! awk -v begin="$BLOCK_BEGIN" -v end="$BLOCK_END" '
    $0 == begin {
      if (seen_begin || inside || seen_end) exit 1
      seen_begin = 1
      inside = 1
      next
    }
    $0 == end {
      if (!inside || seen_end) exit 1
      seen_end = 1
      inside = 0
      next
    }
    END {
      if (inside || seen_begin != seen_end) exit 1
    }
  ' "$profile_path"; then
    fail "配置文件中的 WeKnora 受管区块不完整，请先检查：$profile_path"
  fi
fi

umask 077
temporary_file="$(mktemp "${profile_path}.weknora.XXXXXX")"

if [[ -f "$profile_path" ]]; then
  awk -v begin="$BLOCK_BEGIN" -v end="$BLOCK_END" '
    $0 == begin { inside = 1; next }
    $0 == end { inside = 0; next }
    !inside { print }
  ' "$profile_path" > "$temporary_file"
fi

if [[ -s "$temporary_file" ]]; then
  printf '\n' >> "$temporary_file"
fi
printf '%s\n' "$BLOCK_BEGIN" >> "$temporary_file"
printf 'export WEKNORA_BASE_URL=%q\n' "$base_url" >> "$temporary_file"
printf 'export WEKNORA_API_KEY=%q\n' "$api_key" >> "$temporary_file"
printf '%s\n' "$BLOCK_END" >> "$temporary_file"
chmod 600 "$temporary_file"

if [[ -L "$profile_path" ]]; then
  cp "$temporary_file" "$profile_path"
  chmod 600 "$profile_path"
  rm -f "$temporary_file"
else
  mv "$temporary_file" "$profile_path"
fi
temporary_file=""

key_suffix="${api_key: -4}"
printf '见外知识库环境变量已配置。\n'
printf '配置文件：%s\n' "$profile_path"
printf 'API 地址：%s\n' "$base_url"
printf 'API Key：****%s\n' "$key_suffix"
printf '后续命令可加载该配置文件，完整 Key 不会显示。\n'
