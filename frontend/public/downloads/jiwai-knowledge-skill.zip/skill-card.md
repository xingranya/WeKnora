## Description: <br>
见外知识库通过 WeKnora API 自动配置 macOS/Windows 用户环境变量，并导入文件、网页或 Markdown，执行知识库浏览、混合检索和详情查询。 <br>

此 skill 可用于商业或非商业场景。 <br>

## Publisher: <br>
[lyingbug](https://clawhub.ai/user/lyingbug) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
普通员工首次使用时向 AI 提供完整 API Key，由 AI 自动完成 macOS 或 Windows 用户级环境变量配置；之后可通过 AI 管理见外知识库，包括导入资料、浏览内容及跨知识库混合检索。 <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
风险：见外知识库 API Key 可能允许 AI 创建、编辑或删除知识库内容；用户级环境变量不是加密存储。 <br>
缓解措施：使用满足任务需要的最小权限 Key；执行编辑和删除前明确确认目标；禁止在命令输出、项目文件和最终回复中显示完整 Key。 <br>


## Reference(s): <br>
- [ClawHub skill page](https://clawhub.ai/lyingbug/skills/weknora) <br>


## Skill Output: <br>
**Output Type(s):** [文本、Markdown、代码、shell 命令、配置、操作指引] <br>
**Output Format:** [包含 bash、PowerShell 和 JSON 示例的 Markdown 指引] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [API 调用前自动检查并配置 WEKNORA_BASE_URL 和 WEKNORA_API_KEY。] <br>

## Skill Version(s): <br>
1.2.0（展示名更新为“见外知识库”） <br>

## Ethical Considerations: <br>
用户应确认此 skill 适用于当前环境，并遵守组织的安全、密钥管理和合规要求。 <br>
