[CmdletBinding()]
param()

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

$installerUrl = "https://d.officecli.ai/install.ps1"
$installerSha256 = "ef24f389b27bc5a85142b1d414f3d25047aa62c5188d9b9789940435b22b6c45"
$minimumVersion = [Version]"1.0.144"
$maximumVersionExclusive = [Version]"2.0.0"
$officialInstallDir = Join-Path $env:LOCALAPPDATA "OfficeCLI"
$officialBinary = Join-Path $officialInstallDir "officecli.exe"
$legacyBinary = Join-Path $HOME ".local\bin\officecli.exe"

function Resolve-OfficeCliPath {
    $command = Get-Command officecli -ErrorAction SilentlyContinue
    if ($command -and $command.Source) { return $command.Source }
    foreach ($candidate in @($officialBinary, $legacyBinary)) {
        if (Test-Path $candidate -PathType Leaf) {
            return [IO.Path]::GetFullPath($candidate)
        }
    }
    return $null
}

function Test-CompatibleVersion {
    param([string]$VersionText, [ref]$ParsedVersion)
    return [Version]::TryParse($VersionText, $ParsedVersion) `
        -and $ParsedVersion.Value -ge $minimumVersion `
        -and $ParsedVersion.Value -lt $maximumVersionExclusive
}

$officecliPath = Resolve-OfficeCliPath
if ($officecliPath) {
    $currentVersionText = ((& $officecliPath --version 2>$null) -join "").Trim()
    $parsedVersion = $null
    if ($LASTEXITCODE -eq 0 -and (Test-CompatibleVersion $currentVersionText ([ref]$parsedVersion))) {
        Write-Output "officecli_path=$officecliPath"
        Write-Output "officecli_installed=reused"
        Write-Output "officecli_version=$currentVersionText"
        exit 0
    }
    if ($env:OFFICECLI_REPLACE -ne "1") {
        throw "OfficeCLI 安装失败：已有版本不在支持范围 $minimumVersion 至 $maximumVersionExclusive（不含）内，或无法解析；确认升级或替换后设置 OFFICECLI_REPLACE=1。"
    }
}

$temporaryDir = Join-Path ([IO.Path]::GetTempPath()) ("officecli-install-" + [Guid]::NewGuid().ToString("N"))
New-Item -ItemType Directory -Path $temporaryDir | Out-Null
try {
    $installerPath = Join-Path $temporaryDir "install.ps1"
    Invoke-WebRequest -UseBasicParsing -Uri $installerUrl -OutFile $installerPath
    $actualHash = (Get-FileHash $installerPath -Algorithm SHA256).Hash.ToLowerInvariant()
    if ($actualHash -ne $installerSha256) {
        throw "OfficeCLI 官方安装脚本与 Skill 锁定的 SHA-256 不一致，请先更新 Skill。"
    }
    & powershell -NoProfile -ExecutionPolicy Bypass -File $installerPath
    if ($LASTEXITCODE -ne 0) { throw "OfficeCLI 官方安装脚本执行失败。" }
}
finally {
    Remove-Item -Recurse -Force $temporaryDir -ErrorAction SilentlyContinue
}

$officecliPath = Resolve-OfficeCliPath
if (-not $officecliPath) { throw "OfficeCLI 安装后仍不可用。" }
$officecliDir = Split-Path -Parent $officecliPath
if (($env:Path -split ";") -notcontains $officecliDir) {
    $env:Path = "$officecliDir;$env:Path"
}
& $officecliPath --version *> $null
if ($LASTEXITCODE -ne 0) { throw "OfficeCLI 安装后版本验证失败。" }
$installedVersionText = ((& $officecliPath --version 2>$null) -join "").Trim()
$installedVersion = $null
if (-not (Test-CompatibleVersion $installedVersionText ([ref]$installedVersion))) {
    throw "OfficeCLI 安装版本不在支持范围 $minimumVersion 至 $maximumVersionExclusive（不含）内。"
}

Write-Output "officecli_path=$officecliPath"
Write-Output "officecli_installed=official_installer"
Write-Output "officecli_version=$installedVersionText"
