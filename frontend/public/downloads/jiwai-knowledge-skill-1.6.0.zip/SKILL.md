---
name: weknora
description: >
  通过见外知识库（WeKnora）自动安装并配置 WeKnora CLI 和 OfficeCLI，配置凭据、
  导入、浏览和检索资料，
  并在用户指定的知识库或文件夹范围内获取原文件和可追溯证据，结合 OfficeCLI 新建、重写或修正
  Word，以及新建、修改并计算 Excel。
  适用于知识库管理、文件上传、解析跟踪、单库或跨库检索，以及“基于知识库资料修改 Office
  文件”或“根据知识库撰写报告/表格”的任务；普通的、不依赖见外知识库依据的 Office 编辑不使用此 skill。
metadata:
  version: "1.6.0"
  officecli_tested_against: "1.0.144"
  officecli_supported_range: ">=1.0.144,<2.0.0"
  weknora_cli_release: "cli-main-7f11b7b5b9bb-1"
  weknora_upstream_commit: "7f11b7b5b9bb16f6775cfa5ff2301b94c699a406"
---

# 见外知识库

自动确保 `weknora` CLI 和 OfficeCLI 可用。WeKnora CLI 必须来自腾讯官方源码锁定提交的
CNB 云原生构建，优先用其结构化输出、类型化错误、`--dry-run`
和确认协议执行知识库任务；CLI 尚未覆盖的文件夹、跨库和精细查询使用 REST API 回退。
需要创建或修改 Word/Excel 时，由本 skill 提供知识范围、来源和约束，OfficeCLI 负责真实文件创建、编辑与验收。

## 能力路由

| 用户意图 | 执行路径 |
|---|---|
| 首次使用或任一 CLI 不可用 | 执行平台启动器，自动安装两个 CLI、桥接现有凭据并只读验活 |
| 配置凭据、列出或查看知识库 | 本文件的凭据和查询流程 |
| 上传文件、网页、Markdown，等待解析 | 本文件的上传状态机 |
| 单库或跨库检索 | 本文件的检索契约 |
| 浏览指定知识库文件夹 | 文件夹树 + `folder_path` / `folder_recursive` |
| 下载知识库中的真实原文件 | `GET /knowledge/:id/download`；有官方 CLI 时优先 `weknora doc download` |
| 基于知识库资料新建 Word 报告或 Excel 工作簿 | 先读 `references/office-artifact-workflow.md` 的新建模式，再分别使用 `officecli` Word / Excel 能力 |
| 基于知识库资料重写 Word | 先读 `references/office-artifact-workflow.md`，再使用 `officecli` 的 Word 能力 |
| 基于知识库资料修正 Word | 先读 `references/office-artifact-workflow.md`，再使用 `officecli` 的 Word 能力 |
| 基于知识库资料修改或计算 Excel | 先读 `references/office-artifact-workflow.md`，再使用 `officecli` 的 Excel 能力 |

## 全局强制规则

1. **范围不扩张**：用户指定知识库、文件夹、文件、章节、工作表或单元格后，不得自行扩大范围。
2. **目标必须唯一**：知识库、文件夹或目标文件存在多个同名候选时，展示可区分信息并等待选择，不能取第一条。
3. **检索片段不等于原文件**：修改 DOCX/XLSX 前必须下载真实原文件；`GET /knowledge/:id` 只返回元数据。
4. **证据和目标分离**：区分参考资料、待修改文件、已验证事实、冲突和未知项；检索分数不能充当事实可信度。
5. **不静默覆盖**：Office 任务始终生成新文件；上传结果、下载原件和修改后的产物都不得覆盖已有文件，除非用户明确授权。
6. **不自动回传**：默认只在本地交付修改后的文件。只有用户明确要求回传知识库时，才进入上传确认和解析验收流程。
7. **真实产物验收**：不能用一段文本建议冒充已修改 Word/Excel。必须验证文件可打开、修改范围、格式、公式和关键数值。
8. **密钥不外泄**：完整 API Key 不得出现在回复、日志、项目文件、临时文件或命令行参数中。
9. **证据原件字节不变**：对下载的 DOCX/XLSX 只读取证前后比较 SHA-256；原件发生字节变化时停止，不进入编辑。

## 执行顺序

1. 在任何 WeKnora 请求前执行“CLI 自动安装与验活”。
2. 启动器发现凭据缺失时执行“首次运行与自动配置”，不要要求用户手动编辑环境变量。
3. CLI 验活成功后再继续用户原本的任务；已安装且配置未变时不重复构建或重写配置。
4. 先解析知识库、文件夹和目标文件，确认范围唯一。
5. 涉及远端编辑、删除、重新解析、回传或本地覆盖时，先向用户确认明确目标和影响。
6. Office 任务按“取材 → 证据包 → 原件/新建目标 → OfficeCLI → 验收 → 交付”执行。

## CLI 自动安装与验活

用当前 skill 目录解析脚本绝对路径，不假定 `.claude/skills`、`.agents/skills`
或 `.codex/skills` 中的任何一个是实体目录。

macOS / Linux：

```bash
bash "<skill目录>/scripts/bootstrap_weknora_cli.sh"
```

Windows：

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File "<skill目录>\scripts\bootstrap_weknora_cli_windows.ps1"
```

启动器合同：

- WeKnora CLI 上游锁定为腾讯官方
  `https://github.com/Tencent/WeKnora/tree/7f11b7b5b9bb16f6775cfa5ff2301b94c699a406/cli`。
- 用户端不编译源码；从 CNB 自动构建 Release
  `https://cnb.cool/xingranya/weknora-cli/-/releases/tag/cli-main-7f11b7b5b9bb-1`
  下载当前系统制品。该 Release 的构建、创建和附件上传均由 CNB `tag_push` 流水线完成。
- 先校验 Skill 锁定的 `SHA256SUMS` 哈希，再校验目标二进制哈希、
  `version --format json` 中的上游提交和本地可执行性。
- 目标位置默认为 macOS/Linux 的 `~/.local/bin/weknora`，Windows 的
  `%LOCALAPPDATA%\Programs\WeKnora\weknora.exe`。
- 已有目标二进制且上游提交一致时直接复用，不联网。存在其他版本时不自动覆盖；
  只有用户明确确认替换后才可设置 `WEKNORA_CLI_REPLACE=1`。
- OfficeCLI 仅在 `>=1.0.144,<2.0.0` 时复用；缺失时下载
  `https://d.officecli.ai/install.sh` 或 `install.ps1`，先校验 Skill 锁定的安装脚本 SHA-256。
  官方安装器优先不可变版本 URL、在可用时校验 `SHA256SUMS`，并可能更新用户 PATH、shell RC
  或首次安装 OfficeCLI Skill；不把这些副作用说成见外 ZIP 捆绑了第二个 Skill。
  不在支持范围的已有版本或未验证的 `2.x` 只在用户确认后设置 `OFFICECLI_REPLACE=1` 替换。
- 启动器从现有 `WEKNORA_BASE_URL` 派生 `WEKNORA_HOST`，通过标准输入复用
  `WEKNORA_API_KEY`，不把 Key 放到命令行参数。
- 连接用户自己的知识库必须连续通过两个只读门：脱敏
  `auth status --format json` 和 `kb list --format json`。前者证明凭据归属，后者证明当前 Key
  能访问该私有实例的知识库；不输出用户 ID、邮箱或完整 Key。
- 安装、配置或任一连接门失败时停止 WeKnora 业务操作。同类失败不超过一次自动重试。

启动器输出两个 CLI 路径和安装状态，以及 `configured`、`authenticated`和
`knowledge_base_access`；后续调用优先使用绝对路径，避免当前进程尚未刷新 `PATH` 时误判 CLI 不可用。

## 凭据检查

- 检查当前进程中的 `WEKNORA_BASE_URL` 和 `WEKNORA_API_KEY` 是否均为非空；
  `WEKNORA_HOST` 由配置脚本从 API 地址派生，不单独询问用户。
- Windows 当前进程未读到变量时，再检查用户级环境变量；这是已持久化但当前 AI
  进程尚未继承新变量的正常情况。
- 只报告“已配置”或“未配置”。禁止输出、记录或拼接完整 API Key。
- 两项均存在时直接复用，不重复询问用户，也不覆盖已有配置。

## 首次运行与自动配置

### 1. 向用户索取凭据

任一变量缺失时，向用户发送以下含义的简短提示，然后等待回复：

> 请在见外知识库的“设置 > API 集成 > API Keys”中点击“复制”，把完整 API Key
> 发给我。不要发送页面中带星号的缩略值。默认 API 地址是
> `https://know.seeway.co/api/v1`；如果你使用其他部署地址，请一并发送。

同时遵守以下要求：

- 建议用户创建满足当前任务的最小权限 Key。
- 将用户消息中的完整 Key 视为密钥；之后的命令输出和回复都只能使用脱敏值。
- Key 为空、含空白、含 `*` 或不是 `sk-` 开头时不要写入，重新索取完整 Key。
- 不把 Key 写入项目、由 AI 自行创建的临时文件、脚本参数、提交记录或最终回复。
  macOS 配置脚本内部用于原子更新的临时文件会在完成后立即删除。

### 2. 由 AI 自动写入用户环境

收到有效 Key 后先识别操作系统，再由 AI 执行本 skill 自带脚本。不要把命令交给
用户执行。通过交互式标准输入传入 Key，禁止把 Key 放进命令行参数。

macOS：

```bash
bash "<skill目录>/scripts/configure_macos_env.sh" "https://know.seeway.co/api/v1"
```

脚本提示输入时，将用户提供的 Key 写入标准输入。脚本根据默认 shell 更新：

- zsh：`~/.zprofile`
- bash：`~/.bash_profile`
- 其他 shell：`~/.profile`

脚本只替换见外知识库的受管区块，不修改其他配置，并将配置文件权限设为
仅当前用户可读写。

Windows：

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File "<skill目录>\scripts\configure_windows_env.ps1" -BaseUrl "https://know.seeway.co/api/v1"
```

已安装 PowerShell 7 时也可使用 `pwsh`。脚本提示输入时，将用户提供的 Key 写入
标准输入。脚本通过 Windows 用户级环境变量持久化配置，并通知系统环境已更新。

若用户提供了自定义 API 地址，用该地址替换示例中的默认地址。脚本失败时报告具体
错误并停止，不要反复执行同一失败命令。

### 3. 脱敏验证

配置脚本成功后验证以下三项，不输出变量原值：

1. `WEKNORA_BASE_URL` 与 `WEKNORA_API_KEY` 在持久化位置均非空。
2. `WEKNORA_HOST` 是从以 `/api/v1` 结尾的 API 地址唯一派生的 CLI 服务地址。
3. 用 CLI 连续执行脱敏 `auth status --format json` 和 `kb list --format json`，
   同时证明凭据有效且可读取用户自己的知识库。

若返回 `401`，说明 Key 无效，重新索取完整 Key；若返回 `403`，说明 Key 权限不足，
提示用户创建具备所需只读或写入权限的 Key。验证成功后只回复 API 地址、操作系统、
“凭据已配置”和验证结果，Key 最多显示末四位。

Windows 配置后的当前 AI 进程可能尚未继承新变量。继续当前任务时，从用户级环境变量
读取到当前 PowerShell 进程，不要求用户重启：

```powershell
$env:WEKNORA_BASE_URL = [Environment]::GetEnvironmentVariable("WEKNORA_BASE_URL", "User")
$env:WEKNORA_HOST = [Environment]::GetEnvironmentVariable("WEKNORA_HOST", "User")
$env:WEKNORA_API_KEY = [Environment]::GetEnvironmentVariable("WEKNORA_API_KEY", "User")
```

环境变量本身不是加密存储。只在用户授权的本机环境配置，并避免在共享设备上使用
高权限 Key。

## API 请求模板

所有请求均使用 `$WEKNORA_BASE_URL` 和统一请求头。macOS/Linux shell 中定义：

```bash
wk_api() {
  local method="$1" endpoint="$2" body="${3:-}"
  local request_id
  request_id="$(uuidgen 2>/dev/null || date +%s)"
  local args=(
    --silent --show-error --fail-with-body
    --connect-timeout 20 --max-time "${WEKNORA_TIMEOUT_SECONDS:-120}"
    -X "$method" "$WEKNORA_BASE_URL/$endpoint"
    -H "Content-Type: application/json"
    -H "X-Request-ID: $request_id"
  )
  if [[ -n "$body" ]]; then
    args+=(-d "$body")
  fi
  # 认证头经 stdin 传给 curl，避免完整 API Key 出现在进程参数中。
  printf 'header = "X-API-Key: %s"\n' "$WEKNORA_API_KEY" \
    | curl "${args[@]}" --config -
}
```

上传文件时直接使用 `curl -F`，不要手动设置 `Content-Type`。

启动器通过两个连接门后，优先使用 CLI 的结构化输出、退出码、`--dry-run`
和安全确认；文件夹筛选、跨库检索、指定 `knowledge_ids` 等 CLI 尚未覆盖的能力
使用上述 REST 回退。凭据采用官方 stateless 环境变量路径，不为单次任务创建 CLI profile。

## API 选择表

| 用户意图 | 接口 | 关键参数 |
|---|---|---|
| 列出知识库 | `GET /knowledge-bases` | 无 |
| 查看知识库详情 | `GET /knowledge-bases/:id` | 无 |
| 列出知识库文件夹 | `GET /knowledge-bases/:id/knowledge/folders` | 无 |
| 浏览指定文件夹 | `GET /knowledge-bases/:id/knowledge` | `folder_path`、`folder_recursive`、分页参数 |
| 上传文件 | `POST /knowledge-bases/:id/knowledge/file` | `file`、`enable_multimodel` |
| 导入网页 | `POST /knowledge-bases/:id/knowledge/url` | `url`、`enable_multimodel` |
| 写入 Markdown | `POST /knowledge-bases/:id/knowledge/manual` | `title`、`content`、`tag_ids` |
| 查询解析进度 | `GET /knowledge/:id` | 检查 `parse_status` |
| 查看知识条目元数据 | `GET /knowledge/:id` | 不返回 Office 原文件正文 |
| 下载真实原文件 | `GET /knowledge/:id/download` | 二进制响应，写入新的本地路径 |
| 读取解析后的分块 | `GET /chunks/:knowledge_id` | 分页参数；只用于取材，不替代原文件 |
| 浏览知识库内容 | `GET /knowledge-bases/:id/knowledge` | `page`、`page_size`、`tag_ids`、文件夹筛选 |
| 编辑 Markdown 知识 | `PUT /knowledge/manual/:id` | `title`、`content` |
| 删除知识条目 | `DELETE /knowledge/:id` | 无 |
| 在单个知识库检索 | `POST /knowledge-bases/:id/hybrid-search` | `query_text`、`match_count`、阈值；GET 仅为旧客户端兼容 |
| 跨知识库或指定文件检索 | `POST /knowledge-search` | `query`、`knowledge_base_ids`、可选 `knowledge_ids` |

## 常用流程

### 上传文件并等待解析

```bash
# 1. 查找并唯一确定目标知识库
wk_api GET "knowledge-bases"

# 2. 先检查文件存在、是普通文件、扩展名受支持且大小未超过已知限制。
# 3. 上传一次，并从 data.id 取得 knowledge_id；HTTP 409 表示重复，立即停止。
printf 'header = "X-API-Key: %s"\n' "$WEKNORA_API_KEY" \
  | curl --silent --show-error --fail-with-body --connect-timeout 20 --max-time 600 \
      --config - -X POST "$WEKNORA_BASE_URL/knowledge-bases/<kb_id>/knowledge/file" \
      -F 'file=@document.pdf' -F 'enable_multimodel=true'

# 4. 有官方 CLI 时优先使用带超时的等待命令：
# weknora doc wait <knowledge_id> --timeout 10m --format json

# REST 回退：以 2 秒起步、最高 15 秒退避轮询，默认最多 10 分钟；不得无限轮询。
wk_api GET "knowledge/<knowledge_id>"
```

终态处理：

- `completed`：解析完成；只有此时才可报告“已完成解析”。
- `failed`：停止，展示 `error_message`，不自动重新解析。
- `cancelled`：停止并报告已取消。
- `pending`、`processing`、`finalizing`：继续等待；`finalizing` 表示已进入增强处理阶段。
- `moving`、`deleting`：报告资源正在移动或删除，不继续把它当作正常上传任务。
- 达到超时：报告“仍在处理”，保留知识条目，不把超时说成上传失败。

### 导入网页

```bash
wk_api POST "knowledge-bases/<kb_id>/knowledge/url" \
  '{"url":"https://example.com/article","enable_multimodel":true}'
```

成功后按文件上传流程轮询 `knowledge/:id`。

### 写入 Markdown

```bash
wk_api POST "knowledge-bases/<kb_id>/knowledge/manual" \
  '{"title":"会议记录","content":"# 第一季度复盘\n\n关键事项……"}'
```

### 检索知识

```bash
# 单知识库混合检索
wk_api POST "knowledge-bases/<kb_id>/hybrid-search" \
  '{"query_text":"部署流程","match_count":5}'

# 跨知识库语义检索
wk_api POST "knowledge-search" \
  '{"query":"部署流程","knowledge_base_ids":["kb-1","kb-2"]}'

# 已通过文件夹清单得到 knowledge_ids 时，限定只在这些文件中检索
wk_api POST "knowledge-search" \
  '{"query":"部署流程","knowledge_ids":["doc-1","doc-2"]}'
```

`score` 不是事实可信度或正确率：

- 单库 `hybrid-search` 的基础分通常是 RRF 融合排序分，常见量级约为 `0` 到 `0.03`，不是 0–1 概率。
- 跨库 `knowledge-search` 可能经过重排或复合评分；只能解释当前接口实际返回的阶段，不能与单库原始 RRF 分直接比较。
- `vector_threshold` 和 `keyword_threshold` 在融合前过滤各自通道，不能用最终 `score` 反推阈值是否通过。
- `match_type` 数值：`0` 向量、`1` 关键词、`2` 邻近分块、`3` 历史、`4` 父分块、`5` 关系分块、`6` 图谱、`7` Web、`8` 直接加载、`9` 数据分析。

### 面向用户的查询输出

内部 ID 只用于后续 API/CLI 调用，默认不出现在面向用户的列表和检索结果中。

列出知识库时使用固定投影：

```bash
weknora kb list --format json \
  --jq '{ok:.ok,knowledge_bases:[.data[] | {name,description,knowledge_count,chunk_count,is_processing}]}'
```

跨库检索要求“前 5 条”时，`POST /knowledge-search` 当前没有独立 top-N 请求参数；
保留服务端排序后在客户端截取，不重新排序：

```bash
wk_api POST "knowledge-search" '<request-json>' \
  | jq '.data[:5] | map({knowledge_title,knowledge_filename,chunk_index,match_type,score,content})'
```

输出中将 `match_type` 映射为上述中文含义；`score` 保留原值并标注为“本次检索排序分”。

### 浏览和读取内容

```bash
wk_api GET "knowledge-bases/<kb_id>/knowledge?page=1&page_size=20"
# 精确文件夹；folder_path 为空表示根目录
wk_api GET "knowledge-bases/<kb_id>/knowledge?page=1&page_size=100&folder_path=项目资料&folder_recursive=true"
# 列出文件夹树
wk_api GET "knowledge-bases/<kb_id>/knowledge/folders"
# 元数据，不是原文件正文
wk_api GET "knowledge/<knowledge_id>"
# 解析后的分块文本
wk_api GET "chunks/<knowledge_id>?page=1&page_size=100"
```

下载 Office 原文件时优先使用：

```bash
WEKNORA_HOST="${WEKNORA_BASE_URL%/api/v1}" \
  weknora doc download <knowledge_id> --output <new-local-path> --format json
```

若官方 CLI 不可用，调用 `GET /knowledge/:id/download` 并以二进制方式写入明确的新路径；
禁止把响应或下载路径静默覆盖到已有文件。

## 基于知识库的 Office 任务

用户要求基于指定知识库或文件夹新建、重写、修正 Word，或新建、修改、计算 Excel 时：

1. 必须读取 `references/office-artifact-workflow.md`。
2. 必须加载并遵守可用的 `officecli` skill，同时以当前 `officecli help`
   为命令和属性的最终权威；CLI 不在 `>=1.0.144,<2.0.0` 时停止，不得声称已经创建或修改文件。
3. Word 任务只加载一个最具体的 OfficeCLI Word 专项；Excel 任务只加载一个最具体的 Excel 专项，不能叠加多个专项。
4. 先形成知识交接包，再调用 OfficeCLI。交接包至少包含：
   - `scope`：知识库、文件夹和递归边界；
   - `source_documents`：来源文件、版本、哈希和相关位置；
   - `target_artifact`：`create|edit` 模式、原件（新建时为 null）、输出路径及允许创建/修改范围；
   - `verified_facts`、`constraints`、`conflicts`、`unknowns`；
   - `requested_edits`、`output_path`、`acceptance_checks`。
5. 对冲突或知识库中没有依据的值，不写入 Word/Excel；列入未解决项。
6. 知识驱动的多项修改使用 OfficeCLI 默认原子 `batch --json`；禁止 `--best-effort`。
   批处理失败时必须核对 `atomicRolledBack=true`、失败项 `code` 和 batch 前后文件 SHA-256。
7. OfficeCLI 修改完成后必须 `close` 或 `save`，再执行校验、渲染或交付。
8. 结果必须包含真实文件路径、创建/修改摘要、来源清单、验证结果和未解决项。

## 核心响应字段

- 知识库：`data[]` 中包含 `id`、`name`、`description`、`type`、
  `embedding_model_id`、`knowledge_count`、`chunk_count`、`is_processing`、
  `created_at`。
- 知识条目：`data` 中包含 `id`、`title`、`description`、`type`、
  `parse_status`、`enable_status`、`file_name`、`file_type`、`file_size`、
  `source`、`created_at`、`processed_at`、`error_message`。
- 检索结果：`data[]` 中包含 `id`、`content`、`score`、`knowledge_id`、
  `knowledge_title`、`knowledge_filename`、`chunk_index`、`chunk_type`、
  `match_type`、`metadata`。
- 分页列表：返回 `data[]`、`total`、`page`、`page_size`。

## 状态与分页

- `parse_status`：`pending`、`processing`、`finalizing`、`completed`、`failed`、
  `moving`、`deleting`、`cancelled`。不要把未识别状态当作完成。
- `enable_status`：解析成功后由 `disabled` 自动变为 `enabled`。
- 知识 `type`：`file`、`url`、`manual`。
- 知识库 `type`：`document`、`faq`。
- `chunk_type`：`text`、`summary`、`image`。
- 知识条目列表使用 `page` 和 `page_size`；知识库列表当前返回完整 `data[]`，不要套用分页假设。
- 文件夹列表和文件夹范围查询必须处理全部页；以 `total` 计算终止页，并设置最大页数保护。
- 混合检索最多返回 `match_count` 条，不使用分页。

## 注意事项

- `POST /knowledge-bases/:id/hybrid-search` 是首选；GET + JSON body 只用于兼容旧客户端。
- 文件上传使用 `multipart/form-data`；不要使用 JSON 请求体。
- 支持类型以服务端当前配置为准；视频文件明确不支持。扩展名、MIME 或文件内容冲突时停止。
- `score` 只用于当前检索阶段内排序，不是事实可信度，不得显示为百分比正确率。
- `parse_status` 为 `failed` 时先读取 `error_message`，再决定是否调用
  `POST /knowledge/:id/reparse`；重新解析属于远端写操作，必须先获得用户确认。
- URL 导入受服务端 SSRF 防护约束。被阻止的内网或保留地址应报告实际原因，不得建议关闭安全防护。

## 错误处理

大多数应用错误使用：

```json
{
  "success": false,
  "error": {
    "code": "ERROR_CODE",
    "message": "错误说明",
    "details": "可选详细信息"
  }
}
```

但必须先按 HTTP 状态码分支，不能假设所有错误都使用同一种 JSON：

- 认证或 API-key gate 的提前拒绝可能返回扁平的 `{"error":"..."}`。
- 重复文件/URL 的 `409` 返回 `success:false`、`message`、`code=duplicate_file|duplicate_url` 和已有条目 `data`。
- `curl --fail-with-body` 返回非零时仍需解析响应体；没有拿到非空 `data.id` 时禁止进入轮询。

| HTTP 状态码 | 含义 | 处理方式 |
|---|---|---|
| `400` | 请求错误 | 检查必填字段和参数格式 |
| `401` | 认证失败 | 重新验证 `WEKNORA_API_KEY` |
| `403` | 权限不足 | 检查 Key 的操作权限和知识库范围 |
| `404` | 资源不存在 | 检查资源 ID |
| `409` | 文件或 URL 重复 | 停止，展示已有条目，不自动重试或改名 |
| `413` | 文件过大 | 缩小文件或拆分内容 |
| `429` | 请求受限 | 按服务端提示退避，不立即重复请求 |
| `500` | 服务端错误 | 稍后重试一次；仍失败则报告响应内容 |
